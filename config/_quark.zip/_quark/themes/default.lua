setFont("liberation-mono")
setFontSize(14)

setClearColor(255, 255, 255)
setFrameColor(0, 0, 0)
setBarColor(0, 0, 0)
setBarTextColor(255, 255, 255)

setTextColor(0, 0, 0)
setCursorColor(0, 0, 0)
setMarkColor(0, 0, 0)
setCurrentCharColor(255, 255, 255)
setLineNumberAreaColor(255, 255, 255)
setLineNumberTextColor(0, 0, 0)