setFont("liberation-mono")
setFontSize(14)

setClearColor(40, 40, 40)
setFrameColor(60, 56, 54)
setBarColor(60, 56, 54)
setBarTextColor(227, 219, 169)

setTextColor(227, 219, 169)
setCursorColor(235, 219, 178)
setMarkColor(235, 219, 178)
setCurrentCharColor(40, 40, 40)
setLineNumberAreaColor(40, 40, 40)
setLineNumberTextColor(227, 219, 169)