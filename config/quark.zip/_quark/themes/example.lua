setFont("vera")
setFontSize(15)

setClearColor(0, 0, 255)
setFrameColor(255, 0, 0)
setBarColor(0, 255, 0)
setBarTextColor(0, 0, 0)

setTextColor(255, 165, 0)
setCursorColor(128, 0, 128)
setMarkColor(0, 200, 128)
setCurrentCharColor(0, 255, 255)
setLineNumberAreaColor(255, 0, 255)
setLineNumberTextColor(0, 0, 0)