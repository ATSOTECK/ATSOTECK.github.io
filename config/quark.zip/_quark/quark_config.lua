useTabs(false)
setTabWidth(4)
showLineNumbers(true)

setShowClock(true)
setUseMilitaryTime(false)

setCursorType(cursor_block)
setBlinkCursor(true)

setShowMark(true)

--setUseMouseClick(false)

setWindowOpacity(240)
setFrameRateLimit(60)

setScrollSpeed(100)

setTheme("morning_joe")
--setTheme("example")
--setTheme("default")

debugln("registered globals: " .. globalsCount)
debugln("registered functions: " .. functionsCount)
debugln("registered commands: " .. commandsCount)

--bind(command, key, modifiers ...)

bind(cmd_print_foo, vk_a, vk_control, vk_z)
bind(cmd_quit, vk_w, vk_control, vk_shift)
bind(cmd_load_test, vk_t, vk_control, vk_shift)
bind(cmd_reload_config, vk_r, vk_control)

--bind(cmd_save, vk_s, vk_alt)

--debugln(vk_l)
--vk_l = 2
--debugln(vk_l)

n = 0

function minus()
    if n > 2 then
        n = n - 2
    end
end

--TODO: make below work
--bind("minus", vk_k, vk_control)

function update()
    if n < 100 then
        n = n + 1
    else
        n = 0
    end
    
    control = isKeyDown(vk_control)
    shift = isKeyDown(vk_shift)
    
    if control and shift then
        if isKeyPressed(vk_p) then
            resetPreferences()
            reloadConfig()
        end
    end
    
    if isKeyDown(vk_b) then
        minus()
        debugln(n)
    end
    
    if isKeyDown(vk_y) or isButtonDown(mb_middle) then
        debug(n .. " Hello World!\n")
    end
    
    if isKeyTapped(vk_RControl, 50) then
        debugln("rc")
    end
    
    if isKeyPressed(vk_LControl) then
        debugln("lc")
    end
end
