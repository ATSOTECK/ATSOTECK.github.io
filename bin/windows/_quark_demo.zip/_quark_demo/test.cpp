//�g hef ekki hugmynd um hva� �g er a� gera.
//Here you get to see my terrible code.
#include "CodeEditor.h"

#include "Bindings.h"
#include "Preferences.h"

#include <iostream>
#include <fstream>

//TODO: Move to time file.
#include <Windows.h>

//TODO: have anoption to highlight the current line.

CodeEditor::CodeEditor() {
	//TODO: No hard coded values.
	mPos = Vector2u(4, 42);
	mSize = Vector2u(10, 10);

	getPreferences();

	mCurrentLine = 0;
	mMarkLine = 0;

	Text text("", *Preferences::instance()->getFont(), mFontSize);
	text.setDoMultiColor(false);
	text.setColor(mTextColor);
	text.setPosition(mPos.x + mLineNumberAreaWidth, mPos.y);
	mText.push_back(text);
	
	mClock = Clock();

	addLineNumber();

	mLineIndex = 0;
	mUpperBound = 0;
	mMarkIndex = 0;

	mCode = "Hello";

	mFilename = "";
	mWorkingDirectory = "";

	frames = 0;
	timeNow = mClock.getCurrentTimeInMilliseconds() - 1000;

	mFirstMarkSet = false;
}

CodeEditor::~CodeEditor() {

}

void CodeEditor::getPreferences() {
	Preferences *p = Preferences::instance();

	mFontSize = p->getFontSize();
	mTextColor = p->getTheme().textColor;
	mCursorColor = p->getTheme().cursorColor;
	mMarkColor = p->getTheme().markColor;
	mCurrentCharColor = p->getTheme().currentCharColor;
	mLineNumberAreaColor = p->getTheme().lineNumberAreaColor;
	mLineNumberTextColor = p->getTheme().lineNumberTextColor;
	mTabWidth = p->getTabWidth();
	mLineEnding = "\n"; //TODO: Make this an option.
	mShowLineNumbers = p->showLineNumbers();
	mUseTabs = p->useTabs();
	mShowMark = p->showMark();
	mScrollSpeed = p->getScrollSpeed();

	Font *font = p->getFont();
	Glyph g = font->getGlyph('a', mFontSize, false);
	mFontWidth = staticCastu32(g.advance);

	if (mShowLineNumbers) {
		mLineNumberAreaWidth = mFontSize * 3;
	} else {
		mLineNumberAreaWidth = 0;
	}

	if (mText.size() > 0) {
		for (int i = 0; i < mText.size(); ++i) {
			mText[i].setColor(mTextColor);
			mText[i].setCharSize(mFontSize);
			mText[i].setPosition(mPos.x + mLineNumberAreaWidth, mText[i].getPosition().y);
			mText[i].setFont(*font);
		}
	}

	if (mLineNumbers.size() > 0) {
		for (int i = 0; i < mLineNumbers.size(); ++i) {
			mLineNumbers[i].setColor(mLineNumberTextColor);
			mLineNumbers[i].setCharSize(mFontSize);
			mLineNumbers[i].setFont(*font);
		}
	}

	mLineNumberArea = RectangleShape(mLineNumberAreaWidth, 1920);
	mLineNumberArea.setFillColor(mLineNumberAreaColor);
	mLineNumberArea.setPosition(mPos.x, mPos.y);

	mCursorType = p->getCursorType();
	mBlinkCursor = p->cursorBlinks();
	mShowCursor = true;
	mLastBlinkTime = mClock.getCurrentTimeInMilliseconds();

	if (mCursorType == CursorType::Block) {
		mCursorRect = RectangleShape(g.advance,  font->getLineSpacing(mFontSize));
		mCursorRect.setFillColor(mCursorColor);
	} else if (mCursorType == CursorType::Outline) {
		mCursorRect = RectangleShape(g.advance,  font->getLineSpacing(mFontSize));
		mCursorRect.setOutlineColor(mCursorColor);
		mCursorRect.setOutlineThickness(1);
		mCursorRect.setFillColor(Color::Transparent);
	} else if (mCursorType == CursorType::Underscore) {
		mCursorRect = RectangleShape(g.advance,  2);
		mCursorRect.setFillColor(mCursorColor);
	} else {
		mCursorRect = RectangleShape(1,  font->getLineSpacing(mFontSize));
		mCursorRect.setFillColor(mCursorColor);
	}

	mMarkRect = RectangleShape(g.advance,  font->getLineSpacing(mFontSize));
	mMarkRect.setOutlineColor(mMarkColor);
	mMarkRect.setOutlineThickness(1);
	mMarkRect.setFillColor(Color::Transparent);

	mCurrentChar = Text("", *font, mFontSize);
	mCurrentChar.setDoMultiColor(false);
	mCurrentChar.setColor(mCurrentCharColor);
	mCurrentChar.setPosition(mCursorRect.getPosition());

	//TODO: Topbar will be seperate widget, will be given a code editor to monitor.
	mTopBarText = Text("", *font, mFontSize);
	mTopBarText.setPosition(8, 22);
	mTopBarText.setColor(p->getTheme().barTextColor);

	mTopbar = RectangleShape(128, 22);
	mTopbar.setFillColor(p->getTheme().barColor);
	mTopbar.setPosition(mPos.x, 20);
}

void CodeEditor::enterText(uint32 k) {
	//TODO: Maybe don't ignore alt?
	if (Input::isKeyDown(Input::Control) || Input::isKeyDown(Input::Alt)) {
		return;
	}

	mText[mCurrentLine].insert(incUpperBound(), String(k));
	resetBlink();
}

void CodeEditor::keyPressed(WindowEvent e) {
	Input::Key k = e.key.code;

	checkBindings();
	
	bool control = Input::isKeyDown(Input::Control);
	bool shift = Input::isKeyDown(Input::Shift);

	if (k == Input::Up) {
		moveCursorUpOne();
	} else if (k == Input::Down) {
		moveCursorDownOne();
	} else if (k == Input::Left) {
		resetBlink();

		if (mLineIndex > getLineLength(mCurrentLine)) {
			mLineIndex = getLineLength(mCurrentLine);
		}

		if (mLineIndex == 0 && mCurrentLine != 0) {
			--mCurrentLine;
			mLineIndex = getLineLength(mCurrentLine);
			
			if (mText[mCurrentLine].getPosition().y < mPos.y) {
				scrollUpOne();
			}
		} else if (mLineIndex > 0) {
			if (mLineIndex > mUpperBound) {
				mLineIndex = mUpperBound;
			}

			--mLineIndex;
		}
	} else if (k == Input::Right) {
		resetBlink();

		if (mLineIndex > getLineLength(mCurrentLine)) {
			mLineIndex = getLineLength(mCurrentLine);
		}

		if (mLineIndex == getLineLength(mCurrentLine) && ((mCurrentLine + 1) < getLineCount())) {
			++mCurrentLine;
			mLineIndex = 0;

			if (mText[mCurrentLine].getPosition().y > (mPos.y + mSize.y - (mFontSize * 2))) {
				scrollDownOne();
			}
		} else if (mLineIndex < getLineLength(mCurrentLine)) {
			++mLineIndex;
		}
	}
}

void CodeEditor::mouseButtonPressed(WindowEvent e) {
	if (!Preferences::instance()->useMouseClick() || e.mouseButton.button != Input::MouseLeft) {
		return;
	}
	
	int x = e.mouseButton.x;
	int y = e.mouseButton.y;
	int index = 0;

	if (mShowLineNumbers) {
		x -= mLineNumberAreaWidth;
	}

	//The stupid way. Fixme later.
	for (uint32 i = 0; i < mText.size(); ++i) {
		if (y >= mText[i].getPosition().y && y <= mText[i].getPosition().y + mFontSize + 2) {
			index = i;
			break;
		}
	}

	mCurrentLine = index;
	int xx = 0;
	uint32 lineIndex = 0;

	for (int j = 0; j < getLineLength(mCurrentLine); ++j) {
		uint32 c = getLine(mCurrentLine)[j];

		uint32 charWidth = 0;

		if (c == '\t') {
			charWidth = (getCharWidth(L'') * mTabWidth);
		} else {
			charWidth = getCharWidth(c);
		}

		if (xx + charWidth >= x) {
			break;
		}

		xx += charWidth;
		++lineIndex;
	}

	mLineIndex = lineIndex;
	mUpperBound = mLineIndex;
	resetBlink();
}

void CodeEditor::mouseWheelMoved(WindowEvent e) {
	if (mText.size() == 1) {
		return;
	}

	int dir = e.mouseWheel.delta > 0 ? 1 : -1; 

	//std::cerr << e.mouseWheel.delta * 250 << "\n";
	//std::cerr << ((mFontSize + 2) * 16) << "\n";

	for (uint32 i = 0; i < mText.size(); ++i) {
		mText[i].move(0, mScrollSpeed * dir);
		mLineNumbers[i].move(0, mScrollSpeed * dir);
	}

	resetBlink();
}

void CodeEditor::resizeEvent(WindowEvent e) {
	mSize.x = e.size.width - 8;
	mSize.y = e.size.height - 28;
}

void CodeEditor::setHasFocus(bool focus) {
	mHasFocus = focus;
}

void CodeEditor::checkBindings() {
	BindingManager *bm = BindingManager::instance();
	//Make it so if other keys are pressed ignore it.
	for (uint32 i = 0; i < bm->getBindingCount(); ++i) {
		Binding b = bm->getBinding(i);
		bool key = Input::isKeyDown(b.key);
		bool modifiers = true;

		for (int j = 0; j < b.modifiers.size(); ++j) {
			if (!Input::isKeyDown(b.modifiers[j])) {
				modifiers = false;
				break;
			}
		}

		if (key && modifiers) {
			doCommand(b.cmd);
			return;
		}
	}
}

void CodeEditor::doCommand(uint32 cmd) {
	switch (cmd) {
		case CmdPrintFoo: {
			std::cout << "Foo\n";
		} break;

		case CmdSave: {
			save();
		} break;

		case CmdReloadOpenDocument: {
			reload();
		} break;

		case CmdLoadTest: {
			loadTest();
		} break;

		case CmdMoveUpToBlank: {
			moveCursorUpToBlank();
		} break;

		case CmdMoveDownToBlank: {
			moveCursorDownToBlank();
		} break;

		case CmdMoveToDocumentBegin: {
			moveCursorToDocumentBegin();
		} break;

		case CmdMoveToDocumentEnd: {
			moveCursorToDocumentEnd();
		} break;

		case CmdMoveToLineBegin: {
			moveCursorToLineBegin();
		} break;

		case CmdMoveToLineEnd: {
			moveCursorToLineEnd();
		} break;

		case CmdSetMark: {
			setMark();
		} break;

		case CmdSwapCursorAndMark: {
			swapCursorAndMark();
		} break;

		case CmdMoveCursorToMark: {
			moveCursorToMark();
		} break;

		case CmdToggleMarkVisibility: {
			toggleMarkVisibility();
		} break;

		case CmdBackspace: {
			doBackspace();
		} break;

		case CmdDelete: {
			doDelete();
		} break;

		case CmdClearLine: {
			clearLine(mCurrentLine);
		} break;

		case CmdClearDocument: {
			clear();
		} break;

		case CmdTab: {
			doTab();
		} break;

		case CmdNewline: {
			addLine();
		} break;

		case CmdOpenConfig: {
			loadConfig();
		} break;

		case CmdOpenTheme: {
			loadCurrentTheme();
		} break;

		case CmdLoadHelp: {
			loadReadMe();
		} break;
	}
}

void CodeEditor::update(RenderWindow &window) {
	mTopbar.setSize(window.getWidth() - 8, mTopbar.getSize().y);

	//TODO: move the cursor when the text is scrolled.
	//TODO: make the above optional
	//TODO: make it so that when the cursor is moved outside the view, the view is back on the cursor.

	uint32 cursorY = mText[mCurrentLine].getPosition().y + 2;

	//Check to see if we scrolled to far in either direction.
	if (mText.size() > 1) {
		if (mText[0].getPosition().y > mPos.y) {
			uint32 deltaY = (mText[0].getPosition().y - mPos.y);
			for (uint32 i = 0; i < mText.size(); ++i) {
				mText[i].setPosition(mText[i].getPosition().x, mText[i].getPosition().y - deltaY);
				mLineNumbers[i].setPosition(mLineNumbers[i].getPosition().x, mLineNumbers[i].getPosition().y - deltaY);
			}
		}

		uint32 max = mText.size() - 1;
		if (mText[max].getPosition().y < mPos.y) {
			uint32 deltaY = (mPos.y - mText[max].getPosition().y);
			for (uint32 i = 0; i < mText.size(); ++i) {
				mText[i].setPosition(mText[i].getPosition().x, mText[i].getPosition().y + deltaY);
				mLineNumbers[i].setPosition(mLineNumbers[i].getPosition().x, mLineNumbers[i].getPosition().y + deltaY);
			}
		}

		cursorY = mText[mCurrentLine].getPosition().y + 2;

		if (mText[mCurrentLine].getPosition().y < mPos.y) {
			for (uint32 i = mCurrentLine; i < mText.size(); ++i) {
				if (mText[i].getPosition().y >(mPos.y - mFontSize)) {
					mCurrentLine = i;
					cursorY = mText[i].getPosition().y + 2;
					break;
				}
			}
		} else if (mText[mCurrentLine].getPosition().y > (mPos.y + mSize.y - (mFontSize * 2))) {
			for (int32 i = mCurrentLine; i >= 0; --i) {
				if (mText[i].getPosition().y < (mPos.y + mSize.y - (mFontSize * 2))) {
					mCurrentLine = i;
					cursorY = mText[i].getPosition().y + 2;
					break;
				}
			}
		}
	}

	if (mCursorType == CursorType::Underscore) {
		cursorY += Preferences::instance()->getFont()->getLineSpacing(mFontSize) - 2;
	}

	uint32 cursorX = 0;
	mUpperBound = 0;
	if (mLineIndex >= getLineLength(mCurrentLine)) {
		mUpperBound = getLineLength(mCurrentLine);
	} else {
		mUpperBound = mLineIndex;
	}

	for (int i = 0; i < mUpperBound; ++i) {
		uint32 c = getLine(mCurrentLine)[i];

		if (c == '\t') {
			cursorX += (getCharWidth(L'') * mTabWidth);
		} else {
			cursorX += getCharWidth(c);
		}
	}

	uint32 markX = 0;
	for (int i = 0; i < mMarkIndex; ++i) {
		uint32 c = getLine(mMarkLine)[i];

		if (c == '\t') {
			markX += (getCharWidth(L'') * mTabWidth);
		} else {
			markX += getCharWidth(c);
		}
	}

	uint32 markY = mText[mMarkLine].getPosition().y + 2;

	mCursorRect.setPosition(mPos.x + mLineNumberAreaWidth + cursorX /*offset*/, cursorY);
	mCurrentChar.setPosition(mCursorRect.getPosition().x, mCursorRect.getPosition().y - 2);
	mMarkRect.setPosition(mPos.x + mLineNumberAreaWidth + markX /*offset*/, markY);

	if (mCursorType != CursorType::CursorLine) {
		mCursorRect.setWidth(getCharWidth(getCurrentChar()));
	}

	mMarkRect.setWidth(getCharWidth(getMarkChar()));

	if (!mFirstMarkSet) {
		setMark();
		mFirstMarkSet = true;
	}

	mCurrentChar.setString(getCurrentChar());
	
	SYSTEMTIME theTime;
	GetLocalTime(&theTime);

	bool useMilitaryTime = Preferences::instance()->useMilitaryTime();

	uint32 hour = staticCastu32(theTime.wHour);
	String ampm = hour > 12 ? "PM" : "AM";
	ampm = useMilitaryTime ? "" : ampm;

	if (hour > 12 && !useMilitaryTime) {
		hour -= 12;
	} else if (hour == 0 && !useMilitaryTime) {
		hour = 12;
	}

	String hourStr = String::number(hour);
	String minute = String::number(staticCastu32(theTime.wMinute));
	String second = String::number(staticCastu32(theTime.wSecond));

	if (minute.getLength() == 1) {
		minute.prepend("0");
	}

	if (second.getLength() == 1) {
		second.prepend("0");
	}

	String time = Preferences::instance()->showClock() ? hourStr + ":" + minute + ":" + second + " " + ampm : "";

	if (mClock.getCurrentTimeInMilliseconds() >= (timeNow + 1000)) {
		timeNow = mClock.getCurrentTimeInMilliseconds();
		frameRate = frames;
		frames = 0;
	}

	uint32 p = (staticCastf(mCurrentLine + 1) / staticCastf(getLineCount())) * 100;
	mTopBarText.setString(mFilename + "\t" + String::number(p) + "% " + String::number(mCurrentLine + 1) + ":u" + String::number(mUpperBound) +
		", i" + String::number(mLineIndex) + "\t" + time + "\tfps: " + String::number(frameRate));

	//Draw/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (mShowLineNumbers) {
		window.draw(mLineNumberArea);
	}

	for (int i = 0; i < mText.size(); ++i) {
		if ((mText[i].getPosition().y < (mPos.y - mFontSize)) || (mText[i].getPosition().y >= mPos.y + mSize.y)) {
			continue;
		}

		if (mShowLineNumbers) {
			window.draw(mLineNumbers[i]);
		}

		window.draw(mText[i]);
	}
	
	if (mClock.getCurrentTimeInMilliseconds() >= (mLastBlinkTime + 500)) {
		mLastBlinkTime = mClock.getCurrentTimeInMilliseconds();
		mShowCursor = !mShowCursor;
	}

	if (!mBlinkCursor) {
		mShowCursor = true;
	}

	if (mShowCursor) {
		window.draw(mCursorRect);
	}

	if (mShowMark) {
		window.draw(mMarkRect);
	}

	String str = mCurrentChar.getString();
	if (mShowCursor && mCursorType == CursorType::Block && !str.isEmpty() && str != "\r") {
		window.draw(mCurrentChar);
	}

	window.draw(mTopbar);
	window.draw(mTopBarText);

	++frames;
}

//TODO: if the line added is not visible scroll down one
void CodeEditor::addLine(const String &line) {
	Font *font = Preferences::instance()->getFont();

	Text newLine(line, *font, mFontSize);
	newLine.setDoMultiColor(false);
	newLine.setPosition(mPos.x + mLineNumberAreaWidth, mText[mCurrentLine].getPosition().y + mFontSize + 2);
	newLine.setColor(mTextColor);

	if (mUpperBound < getLineLength(mCurrentLine)) {
		newLine.append(getLine(mCurrentLine).substring(mUpperBound, getLineLength(mCurrentLine) - mUpperBound));
		mText[mCurrentLine].erase(mUpperBound, getLineLength(mCurrentLine) - mUpperBound);
	}

	mUpperBound = 0;
	mLineIndex = 0;

	if (++mCurrentLine > (getLineCount() - 1)) {
		mText.push_back(newLine);
	} else {
		mText.insert(mText.begin() + mCurrentLine, newLine);

		//Shift the lines down.
		for (int i = mCurrentLine + 1; i < mText.size(); ++i) {
			mText[i].setPosition(mPos.x + mLineNumberAreaWidth, mText[i].getPosition().y + mFontSize + 2);
		}
	}

	addLineNumber();
	--mCurrentLine;
	moveCursorDownOne();
}

void CodeEditor::clearLine(uint32 line) {
	if (line < mText.size()) {
		mText[line].setString("");
	}
}

void CodeEditor::doBackspace() {
	if (mUpperBound == 0 && mCurrentLine == 0) {
		return;
	}

	resetBlink();

	if ((mUpperBound == 0 || mText[mCurrentLine].isEmpty()) && mCurrentLine > 0) {
		--mCurrentLine;

		if (!mText[mCurrentLine + 1].isEmpty()) {
			mLineIndex = getLineLength(mCurrentLine);
			mText[mCurrentLine].append(mText[mCurrentLine + 1].getString());
		} else {
			mLineIndex = getLineLength(mCurrentLine);
		}

		//Remove the line.
		mText.erase(mText.begin() + mCurrentLine + 1);
		removeLineNumber();

		if (mCurrentLine < (mText.size() - 1)) {
			for (int i = mCurrentLine + 1; i < mText.size(); ++i) {
				mText[i].setPosition(mPos.x + mLineNumberAreaWidth, mText[i].getPosition().y - mFontSize - 2);
			}
		}

		return;
	}

	String str = mText[mCurrentLine].getString();
	str.erase(mUpperBound - 1, 1);
	mText[mCurrentLine].setString(str);
	if (mUpperBound > 0) {
		if (mLineIndex <= mUpperBound) {
			--mLineIndex;
		}
		--mUpperBound;
	}
}

void CodeEditor::doDelete() {
	if (mUpperBound == getLineLength(mCurrentLine) && mCurrentLine == mText.size() - 1) {
		return;
	}

	resetBlink();

	if (mUpperBound == getLineLength(mCurrentLine)) {

		String str = mText[mCurrentLine + 1].getString();
		mText[mCurrentLine].append(str);

		mText.erase(mText.begin() + mCurrentLine + 1);
		removeLineNumber();

		if (mCurrentLine < (mText.size() - 1)) {
			for (int i = mCurrentLine + 1; i < mText.size(); ++i) {
				mText[i].setPosition(mPos.x + mLineNumberAreaWidth, mText[i].getPosition().y - mFontSize - 2);
			}
		}

		return;
	}

	String str = mText[mCurrentLine].getString();
	str.erase(mUpperBound, 1);
	mText[mCurrentLine].setString(str);
}

void CodeEditor::doTab() {
	resetBlink();
	if (mUseTabs) {
		mText[mCurrentLine].insert(incUpperBound(), "\t");
	} else {
		for (int i = 0; i < mTabWidth; ++i) {
			mText[mCurrentLine].insert(incUpperBound(), " ");
		}
	}
}

bool CodeEditor::cursorAboveView() {
	return mText[mCurrentLine].getPosition().y < mPos.y;
}

bool CodeEditor::cursorBelowView() {
	return mText[mCurrentLine].getPosition().y > mPos.y + mSize.y - (mFontSize * 2);
}

void CodeEditor::moveViewToCursor() {
	if (cursorAboveView()) {
		while (cursorAboveView()) {
			scrollUpOne();
		}
	} else if (cursorBelowView()) {
		while (cursorBelowView()) {
			scrollDownOne();
		}
	}
}

void CodeEditor::moveCursorToDocumentBegin() {
	if (mCurrentLine == 0) {
		return;
	}
	
	mCurrentLine = 0;
	mLineIndex = 0;
	mUpperBound = mLineIndex;

	while (cursorAboveView()) {
		scrollUpOne();
	}

	resetBlink();
}

void CodeEditor::moveCursorToDocumentEnd() {
	if (mCurrentLine == mText.size() - 1) {
		return;
	}

	mCurrentLine = mText.size() - 1;
	mLineIndex = 0;
	mUpperBound = mLineIndex;

	while (cursorBelowView()) {
		scrollDownOne();
	}

	resetBlink();
}

void CodeEditor::moveCursorToLineBegin() {
	if (mUpperBound == getLine(mCurrentLine).firstCharIndex()) {
		return;
	}

	mLineIndex = getLine(mCurrentLine).firstCharIndex();
	mUpperBound = mLineIndex;
	resetBlink();
}

void CodeEditor::moveCursorToLineEnd() {
	if (mUpperBound == getLineLength(mCurrentLine)) {
		return;
	}

	mLineIndex = getLineLength(mCurrentLine);
	mUpperBound = mLineIndex;
	resetBlink();
}

void CodeEditor::moveCursorUpToBlank() {
	if (mCurrentLine == 0) {
		return;
	}

	resetBlink();

	for (int64 i = mCurrentLine - 1; i >= 0; --i) {
		if (mText[i].allWhiteSpace()) {
			mCurrentLine = i + 1;
			//mLineIndex = 0;
			//mUpperBound = mLineIndex;

			while (cursorAboveView()) {
				scrollUpOne();
			}

			return;
		}
	}
}

void CodeEditor::moveCursorDownToBlank() {
	if (mCurrentLine == mText.size() - 1) {
		return;
	}

	resetBlink();

	for (uint32 i = mCurrentLine + 1; i < mText.size(); ++i) {
		if (mText[i].allWhiteSpace()) {
			mCurrentLine = i - 1;
			//mLineIndex = 0;
			//mUpperBound = mLineIndex;

			while (cursorBelowView()) {
				scrollDownOne();
			}
			return;
		}
	}
}

void CodeEditor::moveCursorUpOne() {
	if (mCurrentLine > 0) {
		--mCurrentLine;
		resetBlink();

		if (mText[mCurrentLine].getPosition().y < mPos.y) {
			scrollUpOne();
		}
	}
}

void CodeEditor::moveCursorDownOne() {
	if ((mCurrentLine + 1) < mText.size()) {
		++mCurrentLine;
		resetBlink();

		if (mText[mCurrentLine].getPosition().y > (mPos.y + mSize.y - (mFontSize * 2))) {
			scrollDownOne();
		}
	}
}

void CodeEditor::setMark() {
	mMarkLine = mCurrentLine;
	mMarkIndex = mUpperBound;
}

void CodeEditor::swapCursorAndMark() {
	mMarkRect.setPosition(mCursorRect.getPosition());
	
	uint32 tempIndex = mUpperBound;
	uint32 tempLine = mCurrentLine;

	mLineIndex = mMarkIndex;
	mUpperBound = mLineIndex;
	mCurrentLine = mMarkLine;

	mMarkIndex = tempIndex;
	mMarkLine = tempLine;

	moveViewToCursor();

	resetBlink();
}

void CodeEditor::moveCursorToMark() {
	mLineIndex = mMarkIndex;
	mUpperBound = mLineIndex;
	mCurrentLine = mMarkLine;

	moveViewToCursor();

	resetBlink();
}

void CodeEditor::toggleMarkVisibility() {
	mShowMark = !mShowMark;
}

void CodeEditor::setFont(Font *font) {
	mFont = font;
}

uint32 CodeEditor::getLineLength(uint32 line) const {
	return staticCastu32(mText[line].getString().getLength());
}

uint32 CodeEditor::getLineCount() const {
	return staticCastu32(mText.size());
}

String CodeEditor::getLine(uint32 line) const {
	return mText[line].getString();
}

uint32 CodeEditor::getCurrentChar() const {
	if (mUpperBound == getLineLength(mCurrentLine)) {
		return ' ';
	}

	return getLine(mCurrentLine)[mUpperBound];
}

uint32 CodeEditor::getMarkChar() const {
	if (mMarkIndex == getLineLength(mMarkLine)) {
		return ' ';
	}

	return getLine(mMarkLine)[mMarkIndex];
}

uint32 CodeEditor::getCharWidth(uint32 codePoint) const {
	Font *font = Preferences::instance()->getFont();
	Glyph g;

	if (codePoint == ' ') {
		g = font->getGlyph(L'', mFontSize, false);
	} else {
		g = font->getGlyph(codePoint, mFontSize, false);
	}

	return staticCastu32(g.advance);
}

void CodeEditor::clear() {
	mText.clear();
	mLineNumbers.clear();
	mCurrentLine = 0;
	mLineIndex = 0;
	mUpperBound = 0;

	Text text("", *Preferences::instance()->getFont(), mFontSize);
	text.setDoMultiColor(false);
	text.setColor(mTextColor);
	text.setPosition(mPos.x + mLineNumberAreaWidth, mPos.y);
	mText.push_back(text);

	addLineNumber();
}

//IO

void CodeEditor::save() {
	save(mFilename);
}

void CodeEditor::save(const String &filename) {
	//TODO: Seek and save changed lines only.

	std::ofstream file;
	
	file.open(mWorkingDirectory.toStdString() + filename.toStdString());

	if (!file.is_open()) {
		//TODO: Error
		here
		return;
	}

	for (int i = 0; i < mText.size(); ++i) {
		if (i != mText.size() - 1) {
			file << mText[i].getString().toStdString() + mLineEnding.toStdString();
		} else {
			file << mText[i].getString().toStdString();
		}
	}

	file.flush();
	file.close();
}

void CodeEditor::loadConfig() {
	mWorkingDirectory = Preferences::instance()->getConfigDir();
	mFilename = "quark_config.lua";
	load(mFilename);
}

void CodeEditor::loadReadMe() {
	mWorkingDirectory = "";
	mFilename = "ReadMe.txt";
	load(mFilename);
}

void CodeEditor::loadCurrentTheme() {
	mWorkingDirectory = Preferences::instance()->getConfigDir() + "themes/";
	mFilename = Preferences::instance()->getThemeName() + ".lua";
	std::cout << mWorkingDirectory.toStdString() << "\n";
	load(mFilename);
}

void CodeEditor::loadTest() {
	uint32 ms = mClock.getCurrentTimeInMilliseconds();
	mFilename = "test.cpp";
	mWorkingDirectory = "";
	load(mFilename);

	ms = mClock.getCurrentTimeInMilliseconds() - ms;
	std::cerr << "Load time: " << ms << "\n";
}

void CodeEditor::load(const String &filename) {
	clear();

	std::ifstream file;
	
	file.open(mWorkingDirectory.toStdString() + filename.toStdString());

	if (!file.is_open()) {
		//TODO: Error
		_error
		return;
	}

	bool loadedFirst = false;

	while (!file.eof()) {
		String str = readLine(file);
		if (!loadedFirst) {
			mText[0].setString(str);
			loadedFirst = true;
		} else {
			addLine(str);
		}
		mLineIndex = getLineLength(mCurrentLine);
		mUpperBound = mLineIndex;
	}

	moveCursorToDocumentBegin();
	setMark();

	file.close();
}

void CodeEditor::reload() {
	load(mFilename);
}

void CodeEditor::addLineNumber() {
	uint32 y = mPos.y;
	if (!mLineNumbers.empty()) {
		y = mLineNumbers[mLineNumbers.size() - 1].getPosition().y + mFontSize + 2;
	}

	Text number(String::number(mLineNumbers.size() + 1), *Preferences::instance()->getFont(), mFontSize);
	number.setDoMultiColor(false);
	number.setColor(mLineNumberTextColor);
	number.setPosition(mPos.x + ((mLineNumberAreaWidth - (number.getLength() * mFontWidth)) - mFontWidth), y);
	mLineNumbers.push_back(number);
}

void CodeEditor::removeLineNumber() {
	mLineNumbers.erase(mLineNumbers.end() - 1);
}

void CodeEditor::scrollUpOne() {
	for (uint32 i = 0; i < mText.size(); ++i) {
		mText[i].move(0, mFontSize + 2);
		mLineNumbers[i].move(0, mFontSize + 2);
	}
}

void CodeEditor::scrollDownOne() {
	for (uint32 i = 0; i < mText.size(); ++i) {
		mText[i].move(0, -staticCastf(mFontSize + 2));
		mLineNumbers[i].move(0, -staticCastf(mFontSize + 2));
	}
}

void CodeEditor::resetBlink() {
	mLastBlinkTime = mClock.getCurrentTimeInMilliseconds();
	mShowCursor = true;
}

int CodeEditor::incUpperBound() {
	if (mLineIndex >= getLineLength(mCurrentLine)) {
		mUpperBound = getLineLength(mCurrentLine);
	} else {
		mUpperBound = mLineIndex;
	}

	int preUpperBound = mUpperBound;

	if (++mUpperBound > mLineIndex) {
		mLineIndex = mUpperBound;
	}

	return preUpperBound;
}

String CodeEditor::readLine(std::ifstream &file) {
	char cppIsStupid[2048];
	file.getline(cppIsStupid, 2048);
	return String(cppIsStupid);
}

//�g hef ekki hugmynd um hva� �g er a� gera.